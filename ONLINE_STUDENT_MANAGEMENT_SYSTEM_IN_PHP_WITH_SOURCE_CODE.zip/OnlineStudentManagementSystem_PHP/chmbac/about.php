   <!-- /.row -->
          
                     
            <div class="row">
                 
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3><b>  Mission and Vision</b>
                           </h3>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <p>
                               <h1> VISION</h1>

                                    Universityhood 2025: A Culture of Global Leadership, Quality and Excellence.

                                     

                                   <h1>  MISSION</h1>

                                    Green Valley College Foundation Inc. is committed to develop academic and technopreneurial competencies, facilitate learning experiences and assure the highest standards of quality and excellence and institutional integrity.

                                     

                                   <h1> GOALS</h1>
                                   <ul>
                                    <li>Greatly recognize the need of achieving orderliness, discipline and respect among its internal and external stakeholders in the attainment of the harmonious interpersonal relationship and spirit of oneness.</li>
                                    <li>Highly adhere to its existing policies and standards, rules and regulations as to promote a culture of discipline, i.e.., discipline people, discipline thoughts and discipline actions.</li>
                                    <li>Profoundly advance quality and excellence in its academic and technopreneurial programs through national and international accreditation.</li>
                                    <li>Eminently pursue local and global networking with institutions of higher, Technical – Vocational and basic education.</li>
                                    <li>Energetically promote national and international affiliations, partnership and joint ventures with other organizations to enhance institutional capabilities and competencies.</li>
                                    <li>Apply acknowledge and honor excellence among its internal and external stakeholders, institutional partners country-wide and worldwide.</li>
                                    <li>Deeply cultivate and develop the essentiality and continuous relevant research and extension activities among its personnel and students to promote innovations, inventions and novelties.</li>
                                    <li>Collectively strive and sustain the establishment of Green Valley College Foundation Inc. as a world-class institution from good to great and built to last.</li>
                                   </ul>
                                </p>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
           