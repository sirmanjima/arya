<style type="text/css">
.home >  .pix_diapo , .da-thumbs{
  width: 100%;
}
 .pix_diapo div  img{
    width: 100%;
    height: 100%;
 }
</style>

<div class="home"> 
<div class="pix_diapo">

    <div data-thumb="<?php echo web_root;?>image/image1.jpg">
        <img src="<?php echo web_root;?>image/image1.jpg">
    </div>

    <div data-thumb="<?php echo web_root;?>image/image2.jpg">
        <img src="<?php echo web_root;?>image/image2.jpg"> 
    </div>

    <div data-thumb="<?php echo web_root;?>image/image3.jpg" data-time="7000">
        <img src="<?php echo web_root;?>image/image3.jpg">
    </div>       

    <div data-thumb="<?php echo web_root;?>image/image4" data-time="7000">
        <img src="<?php echo web_root;?>image/image4.jpg">
    </div>

    <div data-thumb="<?php echo web_root;?>image/image5.jpg" data-time="7000">
        <img src="<?php echo web_root;?>image/image5.jpg">
    </div> 
</div><!-- #pix_diapo --> 
    
<ul id="da-thumbs" class="da-thumbs">
    <li class="col-md-3">
        <a href="">
            <img src="images/3.jpg" />
            <div><center><span>Information<br>Technology</span></center></div>
        </a>
    </li>
    <li class="col-md-3">
        <a href="">
            <img src="images/4.jpg" />
            <div><center><span>Business<br>Administration</span></center></div>
        </a>
    </li>
    <li class="col-md-3">
        <a href="">
            <img src="images/5.jpg" />
            <div><center><span>Office<br>Administration</span></center></div>
        </a>
    </li>
    <li class="col-md-3">
        <a href="">
            <img src="images/6.jpg" />
            <div><center><span>Hospitality<br>Management</span></center></div>
        </a>
    </li>
</ul>
</div>


